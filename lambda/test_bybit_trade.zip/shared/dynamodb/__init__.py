"""
DynamoDBアクセス層
"""


