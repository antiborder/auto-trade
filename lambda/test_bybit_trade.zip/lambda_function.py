"""
Bybit取引APIテスト用Lambda関数
ミドルイーストリージョンからBybit APIを呼び出してテストする
"""
import json
import os
import sys
from datetime import datetime

# 共通モジュールのパスを追加
sys.path.insert(0, os.path.dirname(__file__))

from shared.traders.bybit_trader import BybitTrader
from shared.models.trading import Action

def lambda_handler(event, context):
    """Lambdaハンドラー"""
    try:
        # 環境変数からAPIキーを取得
        api_key = os.getenv('BYBIT_API_KEY')
        api_secret = os.getenv('BYBIT_API_SECRET')
        testnet = os.getenv('BYBIT_TESTNET', 'false').lower() == 'true'
        
        if not api_key or not api_secret:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': 'BYBIT_API_KEY and BYBIT_API_SECRET must be set'
                })
            }
        
        # Bybit traderを作成
        trader = BybitTrader(
            trader_id='test-lambda-trader',
            api_key=api_key,
            api_secret=api_secret,
            testnet=testnet
        )
        
        # Lambda関数の実行リージョンを取得（環境変数から、またはコンテキストから）
        import boto3
        region = boto3.Session().region_name or 'unknown'
        
        results = {
            'region': region,
            'testnet': testnet,
            'timestamp': datetime.utcnow().isoformat(),
            'tests': {}
        }
        
        # テスト1: 価格取得
        print("Test 1: Fetching current BTC price...")
        try:
            current_price = trader.get_current_price('BTCUSDT')
            if current_price:
                results['tests']['price_fetch'] = {
                    'status': 'success',
                    'price': current_price.price,
                    'timestamp': current_price.timestamp.isoformat()
                }
            else:
                results['tests']['price_fetch'] = {
                    'status': 'failed',
                    'error': 'Failed to fetch price'
                }
        except Exception as e:
            results['tests']['price_fetch'] = {
                'status': 'error',
                'error': str(e)
            }
        
        # テスト2: 残高取得
        print("Test 2: Fetching balance...")
        try:
            balance = trader.get_balance()
            if "error" not in balance:
                coin_list = balance.get("list", [])
                if coin_list:
                    coins = coin_list[0].get("coin", [])
                    usdt_balance = 0.0
                    btc_balance = 0.0
                    
                    for coin in coins:
                        coin_type = coin.get("coin", "")
                        wallet_balance = coin.get("walletBalance", "")
                        equity = coin.get("equity", "")
                        available_str = wallet_balance or equity or "0"
                        available = float(available_str) if available_str else 0.0
                        
                        if coin_type == "USDT":
                            usdt_balance = available
                        elif coin_type == "BTC":
                            btc_balance = available
                    
                    results['tests']['balance_fetch'] = {
                        'status': 'success',
                        'usdt_balance': usdt_balance,
                        'btc_balance': btc_balance
                    }
                else:
                    results['tests']['balance_fetch'] = {
                        'status': 'failed',
                        'error': 'No coin list in response'
                    }
            else:
                results['tests']['balance_fetch'] = {
                    'status': 'failed',
                    'error': balance.get('error', 'Unknown error')
                }
        except Exception as e:
            results['tests']['balance_fetch'] = {
                'status': 'error',
                'error': str(e)
            }
        
        # テスト3: 小額のテスト注文（0.0001 BTC）
        print("Test 3: Executing test trade...")
        try:
            test_amount_btc = 0.0001
            order = trader.execute_order(
                action=Action.BUY,
                amount=test_amount_btc,
                price=None  # 成行注文
            )
            
            # エラーメッセージからBybit APIのエラーコードを抽出
            error_code = None
            error_msg = getattr(order, 'error_message', None)
            if error_msg:
                # "Bybit API error: ..." の形式からエラーコードを抽出
                import re
                # retCode パターンを探す
                ret_code_match = re.search(r'retCode[:\s]+(\d+)', error_msg)
                if ret_code_match:
                    error_code = ret_code_match.group(1)
            
            results['tests']['trade_execution'] = {
                'status': order.status.value,
                'order_id': order.order_id,
                'amount': order.amount,
                'execution_price': order.execution_price if order.execution_price else None,
                'error_message': error_msg,
                'bybit_error_code': error_code
            }
        except Exception as e:
            results['tests']['trade_execution'] = {
                'status': 'error',
                'error': str(e),
                'error_type': type(e).__name__
            }
        
        return {
            'statusCode': 200,
            'body': json.dumps(results, indent=2, default=str)
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'type': type(e).__name__
            })
        }

